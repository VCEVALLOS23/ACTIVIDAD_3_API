const{ Router } = require('express');
const router =  Router();

router.get("/", (req, res) => {
        res.json({"Title":"BIENVENIDO A LA API_REST"});
    });

module.exports = router;
