const { Router }= require('express');
const router = Router();
const _=require('underscore');

const movies =require('../datos.json');

router.get('/',(req,res) => {
    res.json(movies);
});

router.post('/',(req,res) => {
    const { title, director, year, rating }=req.body;
    if(title && director && year && rating){
        const id =movies.length+1;
        const newMovie = {...req.body, id};
        console.log(newMovie);
        movies.push(newMovie);
        res.json(movies);
    } else {
        res.status(500).json({error:'Petición erronea'});//nos da una información mas detallada de los errores
    }
});

router.put('/:id',(req,res) => { //actualización de datos
    const { id} = req.params;
    const { title, director, year, rating }=req.body;
    if(title && director && year && rating){
        _.each(movies, (movie, i) => {
            if  (movie.id == id) {
            movie.title = title;
            movie.director = director;
            movie.year = year;
            movie.rating = rating;
        }
   });
   res.json(movies);
} else {
    res.status(500).json({error: 'ocurrio un error'});
}
});

router.delete('/:id',(req,res) => {
    const { id} = req.params;
    _.each(movies, (movie, i) => { //nos sirve para recorrer el arreglo de pelicula y obtendremos una cada vez que se recorra
        if (movie.id == id) {
            movies.splice(i,1);
        }
    });
    res.send(movies);
});

module.exports =router;